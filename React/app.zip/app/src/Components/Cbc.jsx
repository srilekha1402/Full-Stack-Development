import React from 'react';
class Cbc extends React.Component{
    render(){
        return <h1>IAM CLASS BASED COMPONENT</h1>
    }
}
export default Cbc;