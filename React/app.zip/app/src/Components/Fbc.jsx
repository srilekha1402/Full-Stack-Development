import React from 'react';
const Fbc =()=>{
    return (
        <h1>I AM FUNCTION BASED COMPONENT</h1>
    )
}
export default Fbc;