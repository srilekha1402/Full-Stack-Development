
import React from 'react'

const Demo = () => {
  return (
    <>
    <h1>hello</h1>
    <h2>helloworld</h2>
    <h3>{5+5}</h3></>
  )
}

export default Demo